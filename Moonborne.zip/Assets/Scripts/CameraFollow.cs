using System;
using Engine.Core;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

public class CameraFollow : GameScript
{
    public float Zoom = 1f;
    public override void Create()
    {
    }

    public override void Update(GameTime gameTime)
    {
        Camera.Main.Target = Owner;
        Camera.Main.Zoom = Zoom;
    }

    public override void Draw(SpriteBatch spriteBatch)
    {
    }

    public override void Destroy()
    {
    }
}