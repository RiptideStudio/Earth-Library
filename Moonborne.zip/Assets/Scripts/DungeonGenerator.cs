using System;
using Engine.Core;
using Engine.Core.CustomMath;
using Engine.Core.Game.Components;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

public class DungeonGenerator : GameScript
{
    TilemapRenderer tilemapRenderer;
    public override void Create()
    {
        Owner.AddComponent(tilemapRenderer = new TilemapRenderer(100,100, "DungeonTileset"));

        for (int i = 0; i < tilemapRenderer.Width; i++)
        {
            for (int j = 0; j < tilemapRenderer.Width; j++)
            {
                tilemapRenderer.SetTile(i, j, 100);
            }
        }
    }

    public override void Update(GameTime gameTime)
    {

    }

    public override void Draw(SpriteBatch spriteBatch)
    {
    }

    public override void Destroy()
    {
    }
}