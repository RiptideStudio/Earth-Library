using Engine.Core;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

public class PlayerMovement : GameScript
{
    public float Speed = 100f;
    public override void Create() 
    {
    }
    public override void Update(GameTime gameTime) 
    {
        Owner.Sprite.frameSpeed = 7;

        if (Input.IsKeyDown(Keys.W))
        {
            Position += new Vector2(0, -Speed) * dt;
            Owner.Sprite.Set("PlayerWalkUp",16,16);
        }
        else if (Input.IsKeyDown(Keys.S))
        {
            Position += new Vector2(0, Speed) * dt;
            Owner.Sprite.Set("PlayerWalkDown",16,16);
        }
        else if (Input.IsKeyDown(Keys.A))
        {
            Position += new Vector2(-Speed, 0) * dt;
            Owner.Sprite.Set("PlayerWalkLeft", 16, 16);
        }
        else if (Input.IsKeyDown(Keys.D))
        {
            Position += new Vector2(Speed, 0) * dt;
            Owner.Sprite.Set("PlayerWalkRight",16,16);
        }
        else
        {
            Owner.Sprite.frameSpeed = 0;
            Owner.Sprite.frame = 0;
        }
        Camera.Main.Target = Owner;
    }

    public override void Draw(SpriteBatch spriteBatch) 
    { 
        
    }

    public override void Destroy() 
    {

    }
}

