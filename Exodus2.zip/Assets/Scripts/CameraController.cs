using Engine.Core;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

public class CameraController : GameScript
{
    public override void Create() 
    { 
        
    }

    public override void Update(GameTime gameTime) 
    { 

    }

    public override void Draw(SpriteBatch spriteBatch) 
    { 
        
    }

    public override void Destroy() 
    {

    }
}

