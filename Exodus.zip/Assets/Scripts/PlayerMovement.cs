using System;
using Engine.Core;
using Engine.Core.Game.Components;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Engine.Core.Graphics;
using Engine.Core.Game;

public class PlayerMovement : GameScript
{
    public float Speed = 1.3f;
    private bool isMoving = false;
    GameObject dungeonGenerator;

    public override void Create()
    {
        dungeonGenerator = GameObject.Instantiate("DungeonGenerator", Vector2.Zero);
    }

    public override void Update(GameTime gameTime)
    {
        isMoving = false;

        Sprite2D sprite = Owner.GetComponent<Sprite2D>();

        if (Input.IsKeyDown(Keys.W))
        {
            Position = new Vector2(Position.X, Position.Y - Speed);
            sprite.Set("PlayerWalkUp");
            isMoving = true;
        }
        if (Input.IsKeyDown(Keys.A))
        {
            Position = new Vector2(Position.X-Speed, Position.Y);

            isMoving = true;
            sprite.Set("PlayerWalkLeft");
        }
        if (Input.IsKeyDown(Keys.S))
        {
            Position = new Vector2(Position.X, Position.Y + Speed);
            sprite.Set("PlayerWalkDown");
            isMoving = true;
        }
        if (Input.IsKeyDown(Keys.D))
        {
            Position = new Vector2(Position.X+Speed, Position.Y);
            isMoving = true;
            sprite.Set("PlayerWalkRight");
        }

        if (!isMoving)
        {
            sprite.Set("PlayerIdleDown");
        }
    }

    public override void Draw(SpriteBatch spriteBatch)
    {
    }

    public override void DrawUI(SpriteBatch spriteBatch)
    {
    }

    public override void Destroy()
    {
    }
}